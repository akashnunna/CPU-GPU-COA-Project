import json
import statistics as st
import threading

from . import config


class Store:
    """Append-only log of REAL measured runs (data/runs.jsonl). Nothing is pre-filled."""

    def __init__(self):
        config.DATA_DIR.mkdir(parents=True, exist_ok=True)
        self.path, self.lock, self.rows = config.DATA_DIR / "runs.jsonl", threading.Lock(), []
        if self.path.exists():
            for line in self.path.read_text().splitlines():
                try:
                    self.rows.append(json.loads(line))
                except ValueError:
                    pass

    def add(self, row):
        with self.lock:
            self.rows.append(row)
            with self.path.open("a") as f:
                f.write(json.dumps(row) + "\n")

    def latest(self, device, sha, image_id=None):
        with self.lock:
            for r in reversed(self.rows):
                if r["device"] == device and r.get("weights_sha256") == sha and (image_id is None or r["image_id"] == image_id):
                    return r
        return None

    def aggregate(self, sha):
        out = {"cpu": None, "gpu": None, "speedup": None}
        with self.lock:
            rows = [r for r in self.rows if r.get("weights_sha256") == sha]
        for dev in ("cpu", "gpu"):
            rs = [r for r in rows if r["device"] == dev]
            if not rs:
                continue
            med = lambda k: (lambda v: round(st.median(v), 3) if v else None)([r[k] for r in rs if r.get(k) is not None])
            out[dev] = {"runs": len(rs), "images": len({r["image_id"] for r in rs}),
                        "execution_time_ms": med("execution_time_ms"), "images_per_second": med("images_per_second"),
                        "utilization_percent": med("utilization_percent"),
                        "cpu_utilization_percent": med("cpu_utilization_percent"),
                        "gpu_utilization_percent": med("gpu_utilization_percent"),
                        "gpu_memory_mb": med("gpu_memory_mb")}
        if out["cpu"] and out["gpu"] and out["gpu"]["execution_time_ms"]:
            out["speedup"] = round(out["cpu"]["execution_time_ms"] / out["gpu"]["execution_time_ms"], 3)
        return out
