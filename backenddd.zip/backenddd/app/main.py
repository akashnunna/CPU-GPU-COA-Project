import io
import re
import uuid
from contextlib import asynccontextmanager
from datetime import datetime, timezone

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from PIL import Image
from pydantic import BaseModel

from . import config, history, monitor
from .errors import DeviceUnavailable
from .store import Store

state = {"engine": None, "error": None}
store = Store()


@asynccontextmanager
async def lifespan(app):
    config.UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    try:
        from .engine import Engine
        state["engine"] = Engine()
        for w in state["engine"].warnings:
            print("WARNING:", w)
    except Exception as e:  # keep serving so /api/health can explain honestly
        state["error"] = f"{type(e).__name__}: {e}"
        print("MODEL NOT LOADED ->", state["error"])
    yield


app = FastAPI(title="CPU vs GPU Performance API", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
                   allow_methods=["*"], allow_headers=["*"])


def engine():
    if state["engine"] is None:
        raise HTTPException(503, f"Model not loaded: {state['error']}")
    return state["engine"]


def find_image(image_id):
    if not re.fullmatch(r"[0-9a-f]{32}", image_id):
        raise HTTPException(400, "Invalid image_id")
    files = list(config.UPLOAD_DIR.glob(f"{image_id}.*"))
    if not files:
        raise HTTPException(404, "Image not found: upload it first")
    return files[0]


@app.get("/api/health")
def health():
    e = state["engine"]
    return {"status": "ok" if e else "degraded", "model_loaded": e is not None, "model_error": state["error"],
            "model": e.info() if e else None, "demo": False}


@app.post("/api/upload")
async def upload(file: UploadFile = File(...)):
    data = await file.read()
    if len(data) > config.MAX_UPLOAD_BYTES:
        raise HTTPException(413, "Image too large (max 25 MB)")
    try:
        Image.open(io.BytesIO(data)).verify()
        img = Image.open(io.BytesIO(data))
        width, height, fmt = img.width, img.height, img.format
    except Exception:
        raise HTTPException(400, "File is not a readable image")
    image_id = uuid.uuid4().hex
    ext = {"JPEG": ".jpg", "PNG": ".png"}.get(fmt, "." + (fmt or "img").lower())
    (config.UPLOAD_DIR / f"{image_id}{ext}").write_bytes(data)
    return {"image_id": image_id, "filename": file.filename, "size_bytes": len(data), "width": width, "height": height}


class InferReq(BaseModel):
    image_id: str


def _speedup(cpu, gpu):
    return round(cpu["execution_time_ms"] / gpu["execution_time_ms"], 3) if cpu and gpu else None


@app.post("/api/infer/{device}")
def infer(device: str, req: InferReq):
    if device not in ("cpu", "gpu"):
        raise HTTPException(404, "device must be 'cpu' or 'gpu'")
    path, eng = find_image(req.image_id), engine()
    try:
        res = eng.infer(device, path)
    except DeviceUnavailable as e:
        raise HTTPException(503, str(e))
    except Exception as e:
        raise HTTPException(500, f"{type(e).__name__}: {e}")
    res["image_id"] = req.image_id
    store.add(res)
    other = store.latest("cpu" if device == "gpu" else "gpu", eng.weights_sha256, req.image_id)
    cpu, gpu = (other, res) if device == "gpu" else (res, other)
    res["speedup"] = _speedup(cpu, gpu)
    return res


@app.get("/api/results")
def results(image_id: str | None = None):
    sha = engine().weights_sha256
    cpu, gpu = store.latest("cpu", sha, image_id), store.latest("gpu", sha, image_id)
    return {"image_id": image_id, "cpu": cpu, "gpu": gpu, "speedup": _speedup(cpu, gpu)}


@app.get("/api/history")
def get_history():
    out, sources, warns = {}, {}, []
    for dev in ("cpu", "gpu"):
        rows, src, warn = history.load(dev)
        if rows:
            out[dev], sources[dev] = rows, src
        if warn:
            warns.append(warn)
    if not out:
        raise HTTPException(404, "No training history found. " + " ".join(warns))
    return {**out, "sources": sources, "warnings": warns}


@app.get("/api/metrics")
def metrics():
    agg = store.aggregate(engine().weights_sha256)
    agg["note"] = "Aggregated (median) over real runs recorded in backend/data/runs.jsonl"
    return agg


@app.get("/api/system")
def system():
    snap = monitor.live_snapshot()
    snap["timestamp"] = datetime.now(timezone.utc).isoformat()
    snap["model"] = state["engine"].info() if state["engine"] else None
    snap["model_error"] = state["error"]
    return snap


@app.get("/api/benchmark")
def benchmark():
    """Read-only: results/inference_benchmark.csv written by your benchmark_inference.py."""
    import csv
    path = config.ROOT / "results" / "inference_benchmark.csv"
    if not path.is_file():
        raise HTTPException(404, "results/inference_benchmark.csv not found: run benchmark_inference.py first")
    rows = []
    with path.open(newline="", encoding="utf-8-sig") as f:
        for r in csv.DictReader(f):
            rows.append({k: (float(v) if k not in ("device", "mode") else v) for k, v in r.items()})
    return {"source": str(path), "rows": rows}
