import platform
import threading
import time

import psutil

try:
    import pynvml
    pynvml.nvmlInit()
    _H = pynvml.nvmlDeviceGetHandleByIndex(0)
except Exception:  # no NVIDIA driver / library
    pynvml, _H = None, None


class Sampler(threading.Thread):
    """Samples real system CPU % (and NVML GPU % if available) while work runs."""

    def __init__(self, interval=0.05):
        super().__init__(daemon=True)
        self.interval, self._halt = interval, threading.Event()
        self.cpu, self.gpu = [], []

    def run(self):
        psutil.cpu_percent(None)
        while not self._halt.is_set():
            time.sleep(self.interval)
            self.cpu.append(psutil.cpu_percent(None))
            if _H:
                try:
                    self.gpu.append(pynvml.nvmlDeviceGetUtilizationRates(_H).gpu)
                except Exception:
                    pass

    def finish(self):
        self._halt.set()
        self.join(timeout=2)
        m = lambda v: round(sum(v) / len(v), 1) if v else None
        return m(self.cpu), m(self.gpu), len(self.cpu)


def nvml_memory_mb():
    if not _H:
        return None
    try:
        return round(pynvml.nvmlDeviceGetMemoryInfo(_H).used / 2**20, 1)
    except Exception:
        return None


def live_snapshot():
    snap = {"cpu_utilization_percent": psutil.cpu_percent(interval=0.2),
            "ram_used_percent": psutil.virtual_memory().percent,
            "cpu_name": platform.processor() or platform.machine(),
            "cpu_cores_logical": psutil.cpu_count(), "cpu_cores_physical": psutil.cpu_count(False),
            "nvml_available": _H is not None, "gpu_utilization_percent": None,
            "gpu_memory_used_mb": None, "gpu_memory_total_mb": None}
    if _H:
        try:
            snap["gpu_utilization_percent"] = pynvml.nvmlDeviceGetUtilizationRates(_H).gpu
            mi = pynvml.nvmlDeviceGetMemoryInfo(_H)
            snap["gpu_memory_used_mb"], snap["gpu_memory_total_mb"] = round(mi.used / 2**20, 1), round(mi.total / 2**20, 1)
        except Exception:
            pass
    return snap
