import copy
import os
import hashlib
import importlib
import inspect
import platform
import statistics as st
import sys
import threading
import time
import types
from datetime import datetime, timezone

import numpy as np
import torch
from PIL import Image

from . import config, monitor
from .errors import DeviceUnavailable
from .trace import build_trace


def _import(spec):
    mod, _, attr = spec.partition(":")
    for p in (config.ROOT, config.ROOT / "src"):
        if p.is_dir() and str(p) not in sys.path:
            sys.path.insert(0, str(p))
    return getattr(importlib.import_module(mod), attr)


_DS_ERROR = [None]


def _project():
    """Your own project modules (config.py, model.py, dataset.py live in the repo root)."""
    for q in (config.ROOT, config.ROOT / "src"):
        if q.is_dir() and str(q) not in sys.path:
            sys.path.insert(0, str(q))
    import config as project_config
    return project_config


def _classes():
    if config.CLASSES_ENV:
        return [c.strip() for c in config.CLASSES_ENV.split(",") if c.strip()], "backend/.env CLASSES"
    try:
        return list(_project().CLASSES), "project config.CLASSES"
    except Exception:
        return config.load_classes()


def _checkpoint_path():
    if config.CHECKPOINT_PATH:
        return config.CHECKPOINT_PATH
    pc = _project()  # same rule as benchmark_inference.py: models/best_<run_name>.pt
    return pc.MODELS_DIR / f"best_{pc.run_name(os.getenv('CHECKPOINT', 'cpu'), False)}.pt"


def _load_cpu_model():
    path = _checkpoint_path()
    if not path.is_file():
        raise RuntimeError(f"Checkpoint not found: {path} (run train.py first, or set CHECKPOINT_PATH)")
    obj = torch.load(str(path), map_location="cpu", weights_only=False)  # your own trusted file
    meta = {"path": str(path)}
    if isinstance(obj, dict) and "model_state" in obj:  # format written by your train.py
        from model import build_model  # your model.py
        _project()
        model = build_model()
        model.load_state_dict(obj["model_state"])
        meta.update(device_trained_on=obj.get("device_trained_on"), best_epoch=obj.get("best_epoch"))
        return model.eval(), meta
    if isinstance(obj, torch.nn.Module):
        return obj.eval(), meta
    state = obj
    if isinstance(obj, dict):
        for k in ("model_state_dict", "state_dict", "model"):
            if isinstance(obj.get(k), dict):
                state = obj[k]
                break
    if not config.MODEL_FACTORY:
        raise RuntimeError("Unrecognised checkpoint format: set MODEL_FACTORY=module:callable in backend/.env")
    model = _import(config.MODEL_FACTORY)(**config.MODEL_KWARGS)
    model.load_state_dict({k.removeprefix("module."): v for k, v in state.items()})
    return model.eval(), meta


def _build_preprocess():
    """Returns (callable PIL->CHW tensor, description, project dataset or None)."""
    ds = None
    try:
        _project()
        from dataset import HAMDataset  # your dataset.py
        ds = HAMDataset("test", train=False)
    except Exception as e:
        ds = None
        _DS_ERROR[0] = f"{type(e).__name__}: {e}"
    if config.PREPROCESS_FACTORY:
        obj = _import(config.PREPROCESS_FACTORY)
        if isinstance(obj, types.FunctionType) and not inspect.signature(obj).parameters:
            obj = obj()
        return obj, f"your code: {config.PREPROCESS_FACTORY}", ds
    if ds is not None:
        for attr in ("transform", "transforms", "tfm", "preprocess", "eval_transform", "test_transform"):
            t = getattr(ds, attr, None)
            if callable(t):
                return t, f"project dataset.HAMDataset.{attr} (same code as training/eval)", ds
    try:  # use the exact values from your config.py
        pc = _project()
        size, mean_v, std_v, src = pc.IMAGE_SIZE, pc.NORM_MEAN, pc.NORM_STD, "project config.py"
    except Exception:
        size, mean_v, std_v, src = config.IMG_SIZE, config.NORM_MEAN, config.NORM_STD, "backend/.env (VERIFY vs training)"
    mean = torch.tensor(mean_v).view(3, 1, 1)
    std = torch.tensor(std_v).view(3, 1, 1)

    def fn(img):
        img = img.resize((size, size), Image.BILINEAR)
        t = torch.from_numpy(np.asarray(img, dtype=np.float32) / 255.0).permute(2, 0, 1)
        return (t - mean) / std
    return fn, f"manual: {size}px, mean={list(mean_v)}, std={list(std_v)} from {src}", ds


def _sha(tensors):
    h = hashlib.sha256()
    for name, t in tensors:
        h.update(name.encode())
        h.update(t.detach().cpu().contiguous().float().numpy().tobytes())
    return h.hexdigest()


class Engine:
    def __init__(self):
        self.lock, self.warnings = threading.Lock(), []
        t0 = time.perf_counter()
        self.cpu_model, self.ckpt_meta = _load_cpu_model()
        self.init_ms = {"cpu": round((time.perf_counter() - t0) * 1000, 1), "gpu": None}
        self.weights_sha256 = _sha(sorted(self.cpu_model.state_dict().items()))
        self.params = sum(p.numel() for p in self.cpu_model.parameters())
        self.classes, self.classes_source = _classes()
        self.preprocess, self.preprocess_source, ds = _build_preprocess()
        self.preprocess_check = self._selfcheck(ds)
        if self.preprocess_check.get('match') is False:
            self.warnings.append(f'Backend preprocessing does NOT match dataset.py output: {self.preprocess_check}')
        if "UNVERIFIED" in self.classes_source:
            self.warnings.append("Class order is the default alphabetical one: set CLASSES to match training.")
        if "VERIFY" in self.preprocess_source:
            self.warnings.append("Manual preprocessing in use: it must match your training/eval transform.")
        self.gpu_model, self.gpu_error, self.gpu_weights_verified = None, None, None
        self._layers = {}
        if not torch.cuda.is_available():
            self.gpu_error = (f"CUDA not available: torch.cuda.is_available() is False "
                              f"(torch {torch.__version__}, built with CUDA {torch.version.cuda}). "
                              "Install a CUDA build of PyTorch / update the NVIDIA driver.")
        else:
            try:
                t0 = time.perf_counter()
                self.gpu_model = copy.deepcopy(self.cpu_model).to("cuda").eval()
                torch.cuda.synchronize()
                self.init_ms["gpu"] = round((time.perf_counter() - t0) * 1000, 1)
                a, b = self.cpu_model.state_dict(), self.gpu_model.state_dict()
                self.gpu_weights_verified = all(torch.equal(a[k], b[k].cpu()) for k in a)
            except Exception as e:
                self.gpu_error = f"GPU model initialisation failed: {type(e).__name__}: {e}"

    def _selfcheck(self, ds):
        """Compare this backend's preprocessing with dataset.py on the first test images."""
        if ds is None:
            return {"checked": False, "reason": "project dataset.py could not be used: " + str(_DS_ERROR[0])}
        try:
            import pandas as pd
            df = pd.read_csv(config.ROOT / "data" / "split_test.csv")
            worst = 0.0
            for i in range(min(3, len(df))):
                mine = self.preprocess(Image.open(df.iloc[i]["image_path"]).convert("RGB")).float()
                ref = ds[i][0].float()
                if mine.shape != ref.shape:
                    return {"checked": True, "match": False, "reason": f"shape {tuple(mine.shape)} vs {tuple(ref.shape)}"}
                worst = max(worst, float((mine - ref).abs().max()))
            return {"checked": True, "match": worst < 1e-4, "max_abs_diff": worst, "images_compared": min(3, len(df))}
        except Exception as e:
            return {"checked": False, "reason": f"{type(e).__name__}: {e}"}

    def info(self):
        return {"checkpoint": self.ckpt_meta, "preprocess_check": self.preprocess_check, "parameters": self.params, "classes": self.classes,
                "classes_source": self.classes_source, "preprocess_source": self.preprocess_source,
                "weights_sha256": self.weights_sha256, "gpu_weights_identical": self.gpu_weights_verified,
                "gpu_available": self.gpu_model is not None, "gpu_error": self.gpu_error,
                "gpu_name": torch.cuda.get_device_name(0) if self.gpu_model is not None else None,
                "torch": torch.__version__, "cuda_build": torch.version.cuda, "cpu_threads": torch.get_num_threads(),
                "init_ms": self.init_ms, "warnings": self.warnings}

    def _profile(self, x):
        key = tuple(x.shape)
        if key in self._layers:
            return self._layers[key]
        rows, hooks = [], []
        if not isinstance(self.cpu_model, torch.jit.ScriptModule):
            def mk(name):
                def h(m, inp, out):
                    if not torch.is_tensor(out):
                        return
                    macs = 0
                    if isinstance(m, torch.nn.Conv2d):
                        macs = out[0].numel() * (m.in_channels // m.groups) * m.kernel_size[0] * m.kernel_size[1]
                    elif isinstance(m, torch.nn.Linear):
                        macs = m.in_features * m.out_features
                    rows.append({"name": name, "type": type(m).__name__, "macs": int(macs),
                                 "param_bytes": sum(p.numel() * p.element_size() for p in m.parameters(recurse=False))})
                return h
            for n, m in self.cpu_model.named_modules():
                if not list(m.children()):
                    hooks.append(m.register_forward_hook(mk(n)))
            try:
                with torch.inference_mode():
                    self.cpu_model(x)
            finally:
                for h in hooks:
                    h.remove()
        self._layers[key] = rows
        return rows

    def infer(self, device, image_path):
        gpu = device == "gpu"
        if gpu and self.gpu_model is None:
            raise DeviceUnavailable(self.gpu_error or "GPU unavailable")
        model = self.gpu_model if gpu else self.cpu_model
        dev = torch.device("cuda" if gpu else "cpu")
        sync = torch.cuda.synchronize if gpu else (lambda: None)
        ms = lambda a: round((time.perf_counter() - a) * 1000, 4)
        with self.lock:  # one measurement at a time so CPU/GPU runs never disturb each other
            t0 = time.perf_counter()
            img = Image.open(image_path)
            img.load()
            file_bytes = image_path.stat().st_size
            t_load = ms(t0)
            t0 = time.perf_counter()
            x = self.preprocess(img.convert("RGB")).unsqueeze(0).float()
            t_pre = ms(t0)
            input_sha = _sha([("x", x)])
            layers = self._profile(x)
            if gpu:
                torch.cuda.reset_peak_memory_stats()
            sync()
            t0 = time.perf_counter()
            xd = x.to(dev)
            sync()
            t_xfer = ms(t0)
            with torch.inference_mode():
                for _ in range(config.WARMUP_RUNS):
                    out = model(xd)
                sync()
                lat = []
                for _ in range(config.TIMED_RUNS):
                    sync()
                    t0 = time.perf_counter()
                    out = model(xd)
                    sync()
                    lat.append((time.perf_counter() - t0) * 1000)
                if out.dim() != 2 or out.shape[1] != len(self.classes):
                    raise RuntimeError(f"Model output shape {tuple(out.shape)} does not match {len(self.classes)} classes")
                t0 = time.perf_counter()
                probs = torch.softmax(out.float(), 1)[0].cpu()
                sync()
                t_cls = ms(t0)
                sampler = monitor.Sampler()
                sampler.start()
                n, start = 0, time.perf_counter()
                while time.perf_counter() - start < config.UTIL_SECONDS:
                    model(xd)
                    n += 1
                sync()
                elapsed = time.perf_counter() - start
                cpu_u, gpu_u, _ = sampler.finish()
            top = torch.topk(probs, min(3, len(self.classes)))
            top3 = [{"class": self.classes[i], "confidence": round(float(p), 6)} for p, i in zip(top.values, top.indices)]
            med = round(st.median(lat), 4)
            timings = {"image_loading": t_load, "preprocessing": t_pre, "host_to_device_transfer": t_xfer if gpu else 0.0,
                       "forward_propagation": med, "classification": t_cls}
            peak = round(torch.cuda.max_memory_allocated() / 2**20, 2) if gpu else None
            return {
                "device": device, "status": "Completed",
                "device_name": torch.cuda.get_device_name(0) if gpu else (platform.processor() or platform.machine()),
                "predicted_class": top3[0]["class"], "confidence": top3[0]["confidence"], "top3": top3,
                "execution_time_ms": med,
                "latency_ms": {"min": round(min(lat), 4), "median": med, "mean": round(st.mean(lat), 4),
                               "max": round(max(lat), 4), "std": round(st.pstdev(lat), 4),
                               "runs": config.TIMED_RUNS, "warmup": config.WARMUP_RUNS},
                "total_pipeline_ms": round(sum(timings.values()), 4), "timings_ms": timings,
                "model_init_ms_at_startup": self.init_ms[device],
                "images_per_second": round(n / elapsed, 3), "sustained_iterations": n, "sustained_seconds": round(elapsed, 3),
                "cpu_utilization_percent": cpu_u, "gpu_utilization_percent": gpu_u,
                "utilization_percent": gpu_u if gpu else cpu_u,
                "gpu_memory_mb": peak, "gpu_memory_basis": "PyTorch peak allocated (weights + activations)" if gpu else None,
                "gpu_memory_used_nvml_mb": monitor.nvml_memory_mb() if gpu else None,
                "weights_sha256": self.weights_sha256, "input_tensor_sha256": input_sha,
                "cpu_threads": torch.get_num_threads(), "batch_size": 1, "model_params": self.params,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "architecture_trace": build_trace(device, layers, timings, file_bytes),
            }