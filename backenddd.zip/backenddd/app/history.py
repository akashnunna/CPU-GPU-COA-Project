"""Reads your EXISTING training history files. Read-only: never writes or retrains."""
import csv
import json
import math

from . import config

ALIASES = {
    "train_acc": ["train_acc", "train_accuracy", "training_accuracy", "accuracy", "acc"],
    "val_acc": ["val_acc", "val_accuracy", "valid_acc", "validation_accuracy", "valid_accuracy"],
    "train_loss": ["train_loss", "training_loss", "loss"],
    "val_loss": ["val_loss", "valid_loss", "validation_loss"],
}


def _find(device):
    p = getattr(config, f"HISTORY_{device.upper()}")
    if p:
        return p if p.is_file() else None
    res = config.ROOT / "results"
    if not res.is_dir():
        return None
    exact = res / f"history_{device}.csv"  # written by your train.py
    if exact.is_file():
        return exact
    c = [f for f in res.rglob("*") if f.suffix.lower() in (".csv", ".json") and device in f.name.lower()
         and any(k in f.name.lower() for k in ("history", "train", "log", "epoch"))]
    return sorted(c, key=lambda f: len(str(f)))[0] if c else None


def _records(path):
    if path.suffix.lower() == ".csv":
        with path.open(newline="", encoding="utf-8-sig") as f:
            return list(csv.DictReader(f))
    d = json.loads(path.read_text())
    if isinstance(d, dict) and isinstance(d.get("history"), (dict, list)):
        d = d["history"]
    if isinstance(d, dict):  # dict of columns
        n = max((len(v) for v in d.values() if isinstance(v, list)), default=0)
        return [{k: v[i] for k, v in d.items() if isinstance(v, list) and i < len(v)} for i in range(n)]
    return d


def _num(v):
    try:
        x = float(v)
        return None if math.isnan(x) else x
    except (TypeError, ValueError):
        return None


def load(device):
    path = _find(device)
    if not path:
        return None, None, f"no {device.upper()} history file found (set HISTORY_{device.upper()} in backend/.env)"
    rows, seen = [], set()
    for i, rec in enumerate(_records(path)):
        rec = {str(k).strip().lower(): v for k, v in rec.items()}
        seen.update(rec)
        row = {"epoch": int(_num(rec.get("epoch")) or i + 1)}
        for key, names in ALIASES.items():
            row[key] = next((_num(rec[n]) for n in names if n in rec and _num(rec[n]) is not None), None)
        if any(row[k] is not None for k in ALIASES):
            rows.append(row)
    if not rows:
        return None, str(path), f"{path.name}: no accuracy/loss columns recognised (columns: {sorted(seen)})"
    return rows, str(path), None
