"""Educational SIMULATED architecture trace. PC/MAR/IR/control are conceptual; MACs/bytes are
analytical (from the model); *_ms values are measured. No hardware registers are read."""

DISCLAIMER = ("SIMULATED architecture trace for teaching. PC, MAR, MDR, IR, ALU and control-unit values "
              "are conceptual, NOT readings of real CPU/GPU registers. Only fields marked measured_ms, "
              "file/param byte counts and analytical MACs come from this run / this model.")
OPS = {"Conv2d": "CONV2D", "Linear": "GEMM", "ReLU": "RELU", "MaxPool2d": "MAXPOOL", "BatchNorm2d": "BNORM",
       "AdaptiveAvgPool2d": "AVGPOOL", "Dropout": "DROPOUT", "Flatten": "FLATTEN"}


def build_trace(device, layers, t, file_bytes):
    gpu, steps, pc = device == "gpu", [], [0]
    cu = "CU: warp scheduler dispatches to SMs" if gpu else "CU: fetch -> decode -> execute -> write-back"

    def add(stage, layer, ir, alu, mdr, ms=None, basis="PC/MAR/IR conceptual"):
        steps.append({"stage": stage, "layer": layer, "pc": f"0x{pc[0]:04X}", "mar": f"0x{0x1000 + 0x40 * len(steps):04X}",
                      "mdr": mdr, "ir": ir, "alu": alu, "control": cu, "measured_ms": ms, "basis": basis})
        pc[0] += 4

    add("Image loading", "image file", "LOAD", "-", f"{file_bytes:,} B", t["image_loading"], "bytes+ms measured; rest conceptual")
    add("Image preprocessing", "resize + normalize", "MUL/ADD", "ALU: per-pixel scale/normalize (runs on CPU in both modes)",
        "input tensor", t["preprocessing"], "ms measured; rest conceptual")
    if gpu:
        add("Model initialization", "host->device copy", "COPY_H2D", "DMA engine (PCIe)", "input tensor",
            t["host_to_device_transfer"], "ms measured; rest conceptual")
    for L in layers[:24]:
        macs = f"{L['macs']:,} MACs (analytical)" if L["macs"] else "element-wise ops"
        add("Forward propagation", f"{L['name']} ({L['type']})", OPS.get(L["type"], L["type"].upper()),
            ("SIMT lanes / tensor cores: " if gpu else "ALU/SIMD: ") + macs, f"{L['param_bytes']:,} B params",
            None, "MACs & bytes analytical from model; PC/MAR/IR conceptual")
    if not layers:
        add("Forward propagation", "TorchScript model", "-", "layer breakdown unavailable", "-", None, "TorchScript: no per-layer hooks")
    add("Forward propagation", "all layers (median latency)", "-", "-", "-", t["forward_propagation"], "measured")
    add("Classification", "softmax + argmax", "EXP/DIV/CMP", "ALU: normalize + compare", "logits", t["classification"], "ms measured")
    return {"kind": "simulated_architecture_trace", "disclaimer": DISCLAIMER, "steps": steps}
