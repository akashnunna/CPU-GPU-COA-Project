class DeviceUnavailable(RuntimeError):
    """Requested hardware (e.g. CUDA) is not available."""
