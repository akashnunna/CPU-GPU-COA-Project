import json
import os
from pathlib import Path

from dotenv import load_dotenv

BACKEND_DIR = Path(__file__).resolve().parents[1]
load_dotenv(BACKEND_DIR / ".env")
ROOT = Path(os.getenv("PROJECT_ROOT") or BACKEND_DIR.parent).resolve()


def _path(name):
    v = os.getenv(name, "").strip()
    if not v:
        return None
    p = Path(v)
    return p if p.is_absolute() else ROOT / p


def _floats(name, default):
    return [float(x) for x in os.getenv(name, default).split(",")]


CHECKPOINT_PATH = _path("CHECKPOINT_PATH")
MODEL_FACTORY = os.getenv("MODEL_FACTORY", "").strip()
MODEL_KWARGS = json.loads(os.getenv("MODEL_KWARGS", "{}") or "{}")
PREPROCESS_FACTORY = os.getenv("PREPROCESS_FACTORY", "").strip()
IMG_SIZE = int(os.getenv("IMG_SIZE", "224"))
NORM_MEAN = _floats("NORM_MEAN", "0.485,0.456,0.406")
NORM_STD = _floats("NORM_STD", "0.229,0.224,0.225")
CLASSES_ENV = os.getenv("CLASSES", "").strip()
CLASSES_FILE = _path("CLASSES_FILE")
HISTORY_CPU = _path("HISTORY_CPU")
HISTORY_GPU = _path("HISTORY_GPU")
WARMUP_RUNS = int(os.getenv("WARMUP_RUNS", "3"))
TIMED_RUNS = int(os.getenv("TIMED_RUNS", "20"))
UTIL_SECONDS = float(os.getenv("UTIL_SECONDS", "1.5"))
UPLOAD_DIR = BACKEND_DIR / "uploads"
DATA_DIR = BACKEND_DIR / "data"
MAX_UPLOAD_BYTES = 25 * 1024 * 1024
DEFAULT_CLASSES = ["akiec", "bcc", "bkl", "df", "mel", "nv", "vasc"]


def load_classes():
    if CLASSES_ENV:
        return [c.strip() for c in CLASSES_ENV.split(",") if c.strip()], "env CLASSES"
    if CLASSES_FILE and CLASSES_FILE.is_file():
        d = json.loads(CLASSES_FILE.read_text())
        if isinstance(d, list):
            return d, str(CLASSES_FILE)
        if all(isinstance(v, int) for v in d.values()):  # name -> index
            return [k for k, _ in sorted(d.items(), key=lambda kv: kv[1])], str(CLASSES_FILE)
        return [v for _, v in sorted(d.items(), key=lambda kv: int(kv[0]))], str(CLASSES_FILE)
    return DEFAULT_CLASSES, "DEFAULT alphabetical HAM10000 order (UNVERIFIED - set CLASSES)"
