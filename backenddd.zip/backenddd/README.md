# Backend (FastAPI + PyTorch)

Place `backend/` and `frontend/` inside your CPU-GPU-COA-Project folder (next to models/, results/, src/).

    cd backend
    copy .env.example .env      (defaults already follow your config.py/model.py/dataset.py)
    python -m pip install -r requirements.txt     (use the SAME python that has CUDA PyTorch)
    python -m uvicorn app.main:app --host 127.0.0.1 --port 8000

Docs: http://127.0.0.1:8000/docs   Health: http://127.0.0.1:8000/api/health

Writes only to backend/uploads and backend/data/runs.jsonl. Never trains, never touches models/ or results/.
